﻿using SmsSend.Models;
using System.Configuration;
using System.Web.Mvc;

namespace SmsSend.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(SmsBody smsBody)
        {
            if (ModelState.IsValid)
            {
                // 取得使用者名稱和密碼
                string username = ConfigurationManager.AppSettings["username"].Trim();
                string password = ConfigurationManager.AppSettings["password"].Trim();
                SmsMain smsMain = new SmsMain(username, password);
                smsMain.SmsBody.Add(smsBody);
                
                // 發送簡訊
                //string result =smsMain.Send();

                //發送簡訊(非同步)
                //string result = smsMain.SendAsync().Result;

                // 發送簡訊(使用 WebRequest)
                string result = smsMain.SendWithWebRequest();
                
                TempData["Result"] = result;

                return RedirectToAction("Index");
            }
            return View(smsBody);
        }
    }
}