﻿namespace SmsSend.Models
{
    public class ErrorUids
    {
        public string Uid { get; set; }
        public string UidStatus { get; set; }
        public string UidStatusMsg { get; set; }
    }
}