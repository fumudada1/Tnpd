﻿<%@ Application Codebehind="Global.asax.cs" Inherits="SmsSend.MvcApplication" Language="C#" %>
