﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using TnpdModels;

namespace DownloadTrafficFile
{
    class Program
    {
        
        static void Main(string[] args)
        {
            BackendContext _db = new BackendContext();
            DateTime startDate=new DateTime(2024,8,1);
            DateTime endDate=new DateTime(2024,8,31);
            List<CaseTraffic> trCases=_db.CaseTraffics.Where(x=>(x.InitDate.Value>=startDate && x.InitDate.Value<=endDate) && (x.itemno== "道交42不依規定使用燈光" || x.itemno== "道交53闖紅燈、紅燈右轉" || x.itemno== "道交48-2轉彎或變換車道不依標誌、標線、號誌指示")).ToList();
            
            Console.WriteLine($"開始下載 {trCases.Count} 筆交通案件附件...\n");

            foreach(CaseTraffic trCase in trCases)
            {
                string fileurl = trCase.Upfile1 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile1;
                string fileur2 = trCase.Upfile2 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile2;
                string fileur3 = trCase.Upfile3 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile3;
                
                //下載檔案到執行檔目錄下的TrafficFiles資料夾
                if (!string.IsNullOrEmpty(trCase.Upfile1))
                {
                    FileDownloader.DownloadFileSync(fileurl, "TrafficFiles");
                }
                if (!string.IsNullOrEmpty(trCase.Upfile2))
                {
                    FileDownloader.DownloadFileSync(fileur2, "TrafficFiles");
                }
                if (!string.IsNullOrEmpty(trCase.Upfile3))
                {
                    FileDownloader.DownloadFileSync(fileur3, "TrafficFiles");
                }
                if (!string.IsNullOrEmpty(trCase.Upfile4))
                {
                    string fileur4 = trCase.Upfile4 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile4;
                    FileDownloader.DownloadFileSync(fileur4, "TrafficFiles");
                }
                if (!string.IsNullOrEmpty(trCase.Upfile5))
                {
                    string fileur5 = trCase.Upfile5 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile5;
                    FileDownloader.DownloadFileSync(fileur5, "TrafficFiles");
                }
                if (!string.IsNullOrEmpty(trCase.Upfile6))
                {
                    string fileur6 = trCase.Upfile6 == null ? "" : "http://trmgt.tnpd.gov.tw/TrafficFiles2/" + trCase.assignUnit.Subject + "/" + trCase.InitDate.Value.ToString("yyyy-MM") + "/" + trCase.CaseID + "/" + trCase.Upfile6;
                    FileDownloader.DownloadFileSync(fileur6, "TrafficFiles");
                }
            }

            Console.WriteLine("\n生成 CSV 報告...");
            var list = trCases.Select(x => new
            {
                案號 = x.CaseID,
                日期 = x.InitDate,
                車號 = x.violation_carno,
                檢舉項目 = x.itemno,
                Upfile1 = x.Upfile1 ,
                Upfile2 = x.Upfile2 ,
                Upfile3 = x.Upfile3 ,
                Upfile4 =  x.Upfile4,
                Upfile5 =  x.Upfile5,
                Upfile6 =  x.Upfile6
            });
            
            //輸出成CSV檔案
            StringBuilder csv = new StringBuilder();
            csv.AppendLine(
                "案號,日期,車號,檢舉項目,Upfile1,Upfile2,Upfile3,Upfile4,Upfile5,Upfile6"
            );
            csv.AppendLine(
                string.Join(
                    Environment.NewLine,
                    list.Select(
                        x =>
                            $"{x.案號},{x.日期},{x.車號},{x.檢舉項目},{x.Upfile1},{x.Upfile2},{x.Upfile3},{x.Upfile4},{x.Upfile5},{x.Upfile6}"
                    )
                )
            );
            
            //寫入檔案
            File.WriteAllText("TrafficCases.csv", csv.ToString(), Encoding.UTF8);
            Console.WriteLine("✓ CSV 檔案已生成: TrafficCases.csv");
            Console.WriteLine("\n下載完成！");
        }
        //建立一個FileDownloader類別()這個專案是.net462所以用WebClient
        public class FileDownloader
        {
            public static void DownloadFile(string fileUrl, string folderName)
            {
                try
                {
                    // 建立目錄如果不存在
                    if (!Directory.Exists(folderName))
                    {
                        Directory.CreateDirectory(folderName);
                    }

                    using (System.Net.WebClient client = new WebClient())
                    {
                        // 設置超時時間（毫秒）
                        client.DownloadFileCompleted += (sender, e) =>
                        {
                            if (e.Error != null)
                            {
                                Console.WriteLine($"下載失敗: {fileUrl}，錯誤: {e.Error.Message}");
                            }
                            else if (e.Cancelled)
                            {
                                Console.WriteLine($"下載已取消: {fileUrl}");
                            }
                            else
                            {
                                Console.WriteLine($"下載成功: {fileUrl}");
                            }
                        };

                        // 設置下載超時
                        client.DownloadFileAsync(new Uri(fileUrl), Path.Combine(folderName, Path.GetFileName(fileUrl)));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"下載錯誤 [{fileUrl}]: {ex.Message}");
                }
            }

            // 同步版本（推薦用於 SSL 問題）
            public static void DownloadFileSync(string fileUrl, string folderName)
            {
                try
                {
                    // 建立目錄如果不存在
                    if (!Directory.Exists(folderName))
                    {
                        Directory.CreateDirectory(folderName);
                    }

                    // 忽略 SSL 證書驗證警告（僅用於開發/測試環境）
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback((sender, cert, chain, sslPolicyErrors) =>
                    {
                        // 返回 true 表示接受所有證書（不安全，僅用於測試）
                        return true;
                    });

                    string fileName = Path.GetFileName(fileUrl);
                    string filePath = Path.Combine(folderName, fileName);

                    using (System.Net.WebClient client = new WebClient())
                    {
                        client.DownloadFile(fileUrl, filePath);
                        Console.WriteLine($"✓ 下載成功: {fileName}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"✗ 下載失敗 [{fileUrl}]: {ex.Message}");
                }
            }
        }
    }
}
